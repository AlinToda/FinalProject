package com.itfactory;

public class Cap extends Cloth {
    public Cap(String color, int size, int quantity) {
        super(color, size, 15.0, quantity);
    }
}
