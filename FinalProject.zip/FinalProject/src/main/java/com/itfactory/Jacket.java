package com.itfactory;

public class Jacket extends Cloth {
    public Jacket(String color, int size, int quantity) {
        super(color, size, 100.0, quantity);
    }
}
