package com.itfactory;

public class TShirt extends Cloth {
    public TShirt(String color, int size, int quantity) {
        super(color, size, 20.0, quantity);
    }
}
