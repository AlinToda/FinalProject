package com.itfactory;

public class Socks extends Cloth {
    public Socks(String color, int size, int quantity) {
        super(color, size, 5.0, quantity);
    }
}