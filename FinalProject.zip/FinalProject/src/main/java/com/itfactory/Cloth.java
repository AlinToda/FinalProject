package com.itfactory;

public abstract class Cloth {
    private String color;
    private int size;
    private double price;
    private int quantity;

    public Cloth(String color, int size, double price, int quantity) {
        this.color = color;
        this.size = size;
        this.price = price;
        this.quantity = quantity;
    }

    public int calculateQuantity() {
        return quantity;
    }

    public double calculatePrice() {
        return price * quantity;
    }

    public String getColor() {
        return color;
    }

    public int getSize() {
        return size;
    }
}