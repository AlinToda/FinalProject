package com.itfactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Cloth> cart = new ArrayList<>();

        System.out.println("Choose a product: ");
        System.out.println("1. T-Shirt");
        System.out.println("2. Jeans");
        System.out.println("3. Socks");
        System.out.println("4. Jacket");
        System.out.println("5. Cap");
        System.out.print("Enter your choice: ");


        while (true) {
            System.out.print("Enter product type (or 'done' to exit): ");
            String productType = scanner.nextLine();

            if (productType.equalsIgnoreCase("done")) {
                break;
            }

            try {
                System.out.print("Enter product color: ");
                String color = scanner.nextLine();
                System.out.print("Enter product size: ");
                int size = Integer.parseInt(scanner.nextLine());
                System.out.print("Enter product quantity: ");
                int quantity = Integer.parseInt(scanner.nextLine());

                switch (productType.toLowerCase()) {
                    case "t-shirt":
                        cart.add(new TShirt(color, size, quantity));
                        break;
                    case "jeans":
                        cart.add(new Jeans(color, size, quantity));
                        break;
                    case "socks":
                        cart.add(new Socks(color, size, quantity));
                        break;
                    case "jacket":
                        cart.add(new Jacket(color, size, quantity));
                        break;
                    case "cap":
                        cart.add(new Cap(color, size, quantity));
                        break;
                    default:
                        System.out.println("Invalid product type!");
                        break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a valid size and quantity.");
            }
        }

        double total = 0.0;
        int totalQuantity = 0;

        System.out.println("Cart Contents:");
        for (Cloth item : cart) {
            System.out.println("Product: " + item.getClass().getSimpleName());
            System.out.println("Color: " + item.getColor());
            System.out.println("Size: " + item.getSize());
            System.out.println("Quantity: " + item.calculateQuantity());
            System.out.println("Price: $" + item.calculatePrice());
            System.out.println();

            total += item.calculatePrice();
            totalQuantity += item.calculateQuantity();
        }

        System.out.println("Total Quantity: " + totalQuantity);
        System.out.println("Total Price: $" + total);

        scanner.close();
    }
}