package com.itfactory;

public class Jeans extends Cloth {
    public Jeans(String color, int size, int quantity) {
        super(color, size, 50.0, quantity);
    }
}